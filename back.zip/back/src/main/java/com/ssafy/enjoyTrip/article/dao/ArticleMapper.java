package com.ssafy.enjoyTrip.article.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ArticleMapper extends ArticleDao {

}
