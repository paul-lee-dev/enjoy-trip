package com.ssafy.enjoyTrip.spot.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SpotMapper extends SpotDao{
}
