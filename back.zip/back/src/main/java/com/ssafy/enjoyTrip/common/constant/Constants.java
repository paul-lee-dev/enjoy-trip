package com.ssafy.enjoyTrip.common.constant;

public class Constants {
    public static final int PAGE_SIZE = 20;
}
