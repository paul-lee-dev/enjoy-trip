//package com.ssafy.enjoyTrip.common.constant;
//
//import lombok.Getter;
//import lombok.RequiredArgsConstructor;
//
//@Getter
//@RequiredArgsConstructor
//public enum Role {
//    GUEST("GUEST"), // securityConfig에서 사용
//    ADMIN("ADMIN"),
//    USER("USER");
//
//    private final String key;
//
//}
