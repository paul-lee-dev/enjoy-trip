package com.ssafy.enjoyTrip.user.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends UserDao {
}
