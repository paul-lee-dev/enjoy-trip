<script setup></script>

<template>
  <div>
    <div class="wrapper">
      <div class="card">
        <img
          src="https://images.unsplash.com/photo-1477666250292-1419fac4c25c?auto=format&fit=crop&w=667&q=80&ixid=dW5zcGxhc2guY29tOzs7Ozs%3D"
        />
        <div class="info">
          <h1>Mountain</h1>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vitae ea animi, at, ducimus
            qui autem quae quos aut molestiae nesciunt possimus blanditiis ut rem expedita ipsam
            odit placeat, reiciendis minima.
          </p>
          <button>Read more</button>
        </div>
      </div>
      <div class="card">
        <img
          src="https://images.unsplash.com/photo-1477666250292-1419fac4c25c?auto=format&fit=crop&w=667&q=80&ixid=dW5zcGxhc2guY29tOzs7Ozs%3D"
        />
        <div class="info">
          <h1>Mountain</h1>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vitae ea animi, at, ducimus
            qui autem quae quos aut molestiae nesciunt possimus blanditiis ut rem expedita ipsam
            odit placeat, reiciendis minima.
          </p>
          <button>Read more</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import '/src/assets/scss/cardItem.sass';
</style>
