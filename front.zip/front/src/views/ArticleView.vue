<script setup>
// import LikeView from '../components/icons/LikeView.vue';
</script>

<template>
  <div class="hello">
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
