<script setup>
import JoinView from '@/components/user/JoinView.vue'
import LoginView from '@/components/user/LoginView.vue'
</script>

<template>
  <div>
    <footer id="footer"></footer>
    <JoinView></JoinView>
    <LoginView></LoginView>
  </div>
</template>

<style scoped></style>
