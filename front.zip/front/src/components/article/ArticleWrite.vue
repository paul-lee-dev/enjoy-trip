<script setup>
import ArticleFormItem from './ArticleFormItem.vue'
</script>

<template>
  <div class="container">
    <div class="articleCreateTitle">
      <p></p>
      <h1>여행 후기 작성</h1>
    </div>

    <div class="col-lg-10 text-start">
      <ArticleFormItem type="regist" />
    </div>

  </div>
</template>

<style scoped></style>
